# Smartbridge-internship
CleanTech: Transforming Waste Management with Transfer Learning
